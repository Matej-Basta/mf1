/// <reference types="react" />
export default function Header(): import("react").JSX.Element;
