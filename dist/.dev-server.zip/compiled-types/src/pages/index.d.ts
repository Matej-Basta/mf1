/// <reference types="react" />
import { InferGetServerSidePropsType } from 'next';
export declare const getServerSideProps: () => Promise<{
    props: {
        products: any;
    };
}>;
export default function Home({ products }: InferGetServerSidePropsType<typeof getServerSideProps>): import("react").JSX.Element;
